/**
 * Represents a town in a graph.
 * This class includes information about the town, such as its name,
 * neighboring towns, distance value used in algorithms, and a reference
 * to the previous town in a path.
 * 
 * @author Remy Tran
 */
public class Town implements Comparable<Town> {
    
    /**
     * Reference to the previous town in a path.
     */
    protected Town previous = null;

    /**
     * Set of neighboring towns.
     */
    protected java.util.Set<Town> neighbors = new java.util.HashSet<Town>();

    /**
     * The distance value used in algorithms (initialized to Integer.MAX_VALUE).
     */
    protected int distance = Integer.MAX_VALUE;

    /**
     * The name of the town.
     */
    protected String name = "";
    

    /**
     * Constructs a town with the given name.
     * 
     * @param n The name of the town.
     */
    public Town(String n) {
        this.name = n;
    }

    /**
     * Constructs a town as a copy of another town.
     * 
     * @param t The town to copy.
     */
    public Town(Town t) {
        this.name = t.name;
        this.distance = t.distance;
        this.neighbors = t.neighbors;
        this.previous = t.previous;
    }

  
    /**
     * Gets the name of the town.
     * 
     * @return The name of the town.
     */
    public String getName() {
        return this.name;
    }

    /**
     * Generates a hash code based on the name of the town.
     * 
     * @return The hash code.
     */
    @Override
    public int hashCode() {
        return this.name.hashCode();
    }

    /**
     * Returns the string representation of the town (its name).
     * 
     * @return The name of the town.
     */
    public String toString() {
        return this.getName();
    }
    
    /**
     * Resets local variables (distance and previous) to default values.
     */
    public void reset() {
        this.distance = Integer.MAX_VALUE;
        this.previous = null;
    }

    /**
     * Compares two towns for equality based on their names (case-insensitive).
     * 
     * @param t The town to compare.
     * @return True if the towns are equal, false otherwise.
     */
    @Override
    public boolean equals(Object t) {
        return t == this || this.name.equalsIgnoreCase(((Town) t).name);
    }

    /**
     * Compares towns based on their names (case-insensitive).
     * 
     * @param t The town to compare.
     * @return A negative integer, zero, or a positive integer as this town is
     *         less than, equal to, or greater than the specified town.
     */
    @Override
    public int compareTo(Town t) {
        return this.name.compareToIgnoreCase(t.name);
    }
}
