import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
/**
 * The TownGraphManager class represents a manager for a graph of towns and roads.
 * It implements the TownGraphManagerInterface, providing methods for managing towns,
 * roads, and various operations on the town graph.
 * @author Remy Tran
 */
public class TownGraphManager implements TownGraphManagerInterface {
    protected GraphInterface<Town, Road> graph = new Graph();

    /**
     * Adds a road between two towns with the specified weight and name.
     * 
     * @param sName The name of the source town.
     * @param dName The name of the destination town.
     * @param w The weight (distance) of the road.
     * @param n The name of the road.
     * @return True if the road was added, false otherwise.
     */
    
    @Override
    public boolean addRoad(String sName, String dName, int w, String n) {
        Town source = getTown(sName);
        Town dest = getTown(dName);
        if (source == null || dest == null) {
            return false;
        }
        if (!graph.containsEdge(source, dest)) {
            graph.addEdge(source, dest, w, n);
        }
        return true;
    }
    

    /**
     * Gets the name of the road between two towns.
     * 
     * @param s The name of the source town.
     * @param d The name of the destination town.
     * @return The name of the road or an empty string if no road exists.
     */
    @Override
    public String getRoad(String s, String d) {
        Road result = graph.getEdge(new Town(s), new Town(d));
        return result == null ? "" : result.getName();
    }

    /**
     * Adds a new town to the graph.
     * 
     * @param s The name of the town to add.
     * @return True if the town was added, false otherwise.
     */
    @Override
    public boolean addTown(String s) {
        return graph.addVertex(new Town(s));
    }

    
    /**
     * Gets the Town object with the specified name.
     * 
     * @param s The name of the town to retrieve.
     * @return The Town object or null if not found.
     */
    @Override
    public Town getTown(String s) {
        java.util.Set<Town> towns = graph.vertexSet();
        Town result = null;
        for (Town t : towns) {
            if (t.getName().equals(s)) {
                result = t;
                break;
            }
        }
        return result;
    }

    
    /**
     * Checks if a town with the specified name exists in the graph.
     * 
     * @param s The name of the town to check.
     * @return True if the town exists, false otherwise.
     */
    @Override
    public boolean containsTown(String s) {
        return getTown(s) != null;
    }

    
    /**
     * Deletes a town from the graph.
     * 
     * @param s The name of the town to delete.
     * @return True if the town was deleted, false otherwise.
     */
    @Override
    public boolean deleteTown(String s) {
        return graph.removeVertex(getTown(s));
    }

    
    /**
     * Checks if a road connection exists between two towns.
     * 
     * @param s The name of the source town.
     * @param d The name of the destination town.
     * @return True if a road connection exists, false otherwise.
     */
    @Override
    public boolean containsRoadConnection(String s, String d) {
        return graph.containsEdge(getTown(s), getTown(d));
    }
    
    

    /**
     * Deletes a road connection between two towns with a specified road name.
     * 
     * @param s The name of the source town.
     * @param d The name of the destination town.
     * @param n The name of the road to delete.
     * @return True if the road connection was deleted, false otherwise.
     */
    @Override
    public boolean deleteRoadConnection(String s, String d, String n) {
        return graph.removeEdge(getTown(s), getTown(d), -1, n) != null;
    }

    /**
     * Gets a list of all roads in the graph, sorted alphabetically.
     * 
     * @return ArrayList of road names.
     */
    
    @Override
    public java.util.ArrayList<String> allRoads() {
        java.util.ArrayList<String> result = new java.util.ArrayList<String>();
        java.util.Set<Road> roads = graph.edgeSet();
        for (Road r : roads) {
            result.add(r.toString());
        }
        java.util.Collections.sort(result, (s1, s2) -> java.text.Collator.getInstance().compare(s1, s2));
        return result;
    }

    /**
     * Gets a list of all towns in the graph, sorted alphabetically.
     * 
     * @return ArrayList of town names.
     */
    @Override
    public java.util.ArrayList<String> allTowns() {
        java.util.ArrayList<String> result = new java.util.ArrayList<String>();
        java.util.Set<Town> towns = graph.vertexSet();
        for (Town t : towns) {
            result.add(t.toString());
        }
        java.util.Collections.sort(result, (s1, s2) -> java.text.Collator.getInstance().compare(s1, s2));
        return result;
    }

    /**
     * Gets the shortest path between two towns in the graph.
     * 
     * @param s The name of the source town.
     * @param d The name of the destination town.
     * @return ArrayList of strings representing the path.
     */
    @Override
    public java.util.ArrayList<String> getPath(String s, String d) {
        return graph.shortestPath(getTown(s), getTown(d));
    }

    /**
     * Populates the town graph from a file.
     * 
     * @param file The file containing road information.
     * @throws java.io.FileNotFoundException if the file is not found.
     * @throws java.io.IOException if an I/O error occurs.
     */
    public void populateTownGraph(File file) throws FileNotFoundException, IOException {
        ArrayList<String> lines;
        try {
            lines = readFile(file);
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
            return; // or handle the exception based on your application's needs
        }

        for (String line : lines) {
            String[] roadParts = line.split(";");
            if (roadParts.length == 3) {
                try {
                    String[] roadInfo = roadParts[0].split(",");
                    if (roadInfo.length == 2) {
                        String roadName = roadInfo[0].trim();
                        int weight = Integer.parseInt(roadInfo[1].trim());
                        String source = roadParts[1].trim();
                        String destination = roadParts[2].trim();

                        addTown(source);
                        addTown(destination);
                        addRoad(source, destination, weight, roadName);
                    }
                } catch (NumberFormatException e) {
                    System.err.println("Error parsing line: " + line);
                    // Log or handle the exception as appropriate for your application
                }
            }
        }
    }
    /**
     * Reads lines from a file and returns them as an ArrayList of strings.
     * 
     * @param file The file to read.
     * @return ArrayList of strings containing the lines from the file.
     * @throws java.io.FileNotFoundException if the file is not found.
     * @throws java.io.IOException if an I/O error occurs.
     */
    protected java.util.ArrayList<String> readFile(java.io.File file) throws java.io.FileNotFoundException, java.io.IOException {
        java.util.ArrayList<String> result = new java.util.ArrayList<String>();
        try (java.util.Scanner scanner = new java.util.Scanner(file)) {
            while (scanner.hasNextLine()) {
                result.add(scanner.nextLine());
            }
        }
        return result;
    }
}
