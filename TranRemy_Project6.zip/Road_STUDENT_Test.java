import static org.junit.Assert.*;
import org.junit.Test;
public class Road_STUDENT_Test {
	/*
	 * @author Remy Tran
	*/
	
	@Test
    public void testGetStart() {
        Town start = new Town("TownC");
        Town end = new Town("TownD");
        Road road = new Road(start, end, 2, "RoadCD");

        assertEquals(start, road.getStart());
    }

    @Test
    public void testGetEnd() {
        Town start = new Town("TownS");
        Town end = new Town("TownT");
        Road road = new Road(start, end, 4, "RoadST");

        assertEquals(end, road.getEnd());
    }

    @Test
    public void testGetName() {
        Town start = new Town("TownR");
        Town end = new Town("TownT");
        Road road = new Road(start, end, 3, "RoadRT");

        assertEquals("RoadRT", road.getName());
    }

    @Test
    public void testContains() {
        Town townA = new Town("TownA");
        Town townB = new Town("TownB");
        Town townC = new Town("TownC");

        Road road = new Road(townA, townB, 5, "RoadAB");

        assertTrue(road.contains(townA));
        assertTrue(road.contains(townB));
        assertFalse(road.contains(townC));
    }

    @Test
    public void testHashCode() {
        Town start = new Town("TownX");
        Town end = new Town("TownY");
        Road road1 = new Road(start, end, 3, "RoadXY");
        Road road2 = new Road(start, end, 3, "RoadXY");
        Road road3 = new Road(start, end, 5, "RoadXY"); 

        assertEquals(road1.hashCode(), road2.hashCode());
        assertNotEquals(road1.hashCode(), road3.hashCode());
    }

    @Test
    public void testGetWeight() {
        Town start = new Town("TownU");
        Town end = new Town("TownV");
        Road road = new Road(start, end, 6, "RoadUV");

        assertEquals(6, road.getWeight());
    }

    @Test
    public void testToString() {
        Town start = new Town("TownA");
        Town end = new Town("TownB");
        Road road = new Road(start, end, 5, "RoadAB");

        assertEquals("RoadAB", road.toString());
    }

    @Test
    public void testCompareTo() {
        Road road1 = new Road(new Town("TownD"), new Town("TownU"), 3, "RoadDU");
        Road road2 = new Road(new Town("TownF"), new Town("TownL"), 5, "RoadFL");
        Road road3 = new Road(new Town("TownK"), new Town("TownO"), 2, "RoadKO");

        assertTrue(road1.compareTo(road2) < 0);
        assertTrue(road2.compareTo(road3) > 0);
        assertEquals(0, road1.compareTo(road1));
        assertTrue(road1.compareTo(road3) > 0); 
    }
}

