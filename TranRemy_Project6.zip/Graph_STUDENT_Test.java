import static org.junit.Assert.*;

/*
 * @author Remy Tran
 */
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.util.*;
public class Graph_STUDENT_Test {
	private GraphInterface<Town,Road> graph;
	private Town[] town;

	@Before
    public void setUp() throws Exception {
		 // Initialize the graph and towns before each test
        graph = new Graph();
        town = new Town[15];
     // Create and add towns to the graph
        for (int i = 1; i < 15; i++) {
            town[i] = new Town("Town_" + i);
            graph.addVertex(town[i]);
        }
     // Add roads (edges) between towns in the graph
        graph.addEdge(town[1], town[2], 3, "Road_1");
        graph.addEdge(town[1], town[3], 5, "Road_2");
        graph.addEdge(town[1], town[5], 7, "Road_3");
        graph.addEdge(town[3], town[7], 2, "Road_4");
        graph.addEdge(town[3], town[8], 4, "Road_5");
        graph.addEdge(town[4], town[8], 1, "Road_6");
        graph.addEdge(town[6], town[9], 4, "Road_7");
        graph.addEdge(town[9], town[10], 3, "Road_8");
        graph.addEdge(town[8], town[10], 5, "Road_9");
        graph.addEdge(town[5], town[10], 6, "Road_10");
        graph.addEdge(town[10], town[11], 2, "Road_11");
        graph.addEdge(town[2], town[11], 8, "Road_12");
        graph.addEdge(town[2], town[12], 3, "Road_13");
        graph.addEdge(town[12], town[13], 1, "Road_14");
        graph.addEdge(town[13], town[14], 4, "Road_15");
    }
	
	// Test the getEdge method to retrieve edges between towns
	@Test
    public void testGetEdge() {
        assertEquals(new Road(town[8], town[10], 5, "Road_9"), graph.getEdge(town[8], town[10]));
        assertEquals(new Road(town[13], town[14], 4, "Road_15"), graph.getEdge(town[13], town[14]));
    }
	 // Test the addVertex method to ensure new towns are added correctly
	@Test
    public void testAddVertex() {
        Town newTown = new Town("Town_16");
        assertEquals(false, graph.containsVertex(newTown));
        graph.addVertex(newTown);
        assertEquals(true, graph.containsVertex(newTown));
    }
	
	// Test the containsEdge method to check if the graph contains specific edges
	@Test
    public void testContainsEdge() {
        Town townA = new Town("Town_2");
        Town townB = new Town("Town_11");
        assertEquals(true, graph.containsEdge(townA, townB));
        assertEquals(false, graph.containsEdge(town[3], town[6]));
    }
	
	// Test the containsVertex method to check if the graph contains specific towns
	@Test
    public void testContainsVertex() {
        Town newTown = new Town("Town_2");
        assertEquals(true, graph.containsVertex(newTown));
        assertEquals(false, graph.containsVertex(new Town("Town_16")));
    }
	
	// Test the edgeSet method to get a set of all edges in the graph
	@Test
    public void testEdgeSet() {
        Set<Road> roads = graph.edgeSet();
        ArrayList<String> roadArrayList = new ArrayList<String>();
        for (Road road : roads)
            roadArrayList.add(road.getName());
        Collections.sort(roadArrayList);
        assertEquals("Road_1", roadArrayList.get(0));
        assertEquals("Road_10", roadArrayList.get(1));
        assertEquals("Road_11", roadArrayList.get(2));
        assertEquals("Road_12", roadArrayList.get(3));
        assertEquals("Road_13", roadArrayList.get(4));
        assertEquals("Road_5", roadArrayList.get(10));
        assertEquals("Road_8", roadArrayList.get(13));
    }
	
	// Test the edgesOf method to get a set of edges connected to a specific town
	@Test
    public void testEdgesOf() {
        Set<Road> roads = graph.edgesOf(town[1]);
        ArrayList<String> roadArrayList = new ArrayList<String>();
        for (Road road : roads)
            roadArrayList.add(road.getName());
        Collections.sort(roadArrayList);
        assertEquals("Road_1", roadArrayList.get(0));
        assertEquals("Road_2", roadArrayList.get(1));
        assertEquals("Road_3", roadArrayList.get(2));
    }
	
	
	 @Test
	    public void testRemoveEdge() {
	        assertEquals(true, graph.containsEdge(town[2], town[11]));
	        graph.removeEdge(town[2], town[11], 8, "Road_12");
	        assertEquals(false, graph.containsEdge(town[2], town[11]));
	    }
	 
	 @Test
	    public void testRemoveVertex() {
	        assertEquals(true, graph.containsVertex(town[8]));
	        graph.removeVertex(town[8]);
	        assertEquals(false, graph.containsVertex(town[8]));
	    }
	 
	 
	 @Test
	    public void testVertexSet() {
	        Set<Town> towns = graph.vertexSet();
	        assertEquals(true, towns.contains(town[13]));
	        assertEquals(true, towns.contains(town[3]));
	        assertEquals(true, towns.contains(town[4]));
	        assertEquals(true, towns.contains(town[7]));
	        assertEquals(true, towns.contains(town[9]));
	    }
	 
	 
	 @Test
	    public void testTown_1ToTown_14() {
	        String beginTown = "Town_1", endTown = "Town_14";
	        Town beginIndex = null, endIndex = null;
	        Set<Town> towns = graph.vertexSet();
	        Iterator<Town> iterator = towns.iterator();
	        while (iterator.hasNext()) {
	            Town town = iterator.next();
	            if (town.getName().equals(beginTown))
	                beginIndex = town;
	            if (town.getName().equals(endTown))
	                endIndex = town;
	        }
	        if (beginIndex != null && endIndex != null) {

	            ArrayList<String> path = graph.shortestPath(beginIndex, endIndex);
	            assertNotNull(path);
	            assertTrue(path.size() > 0);
	            assertEquals("Town_1 via Road_1 to Town_2 3 mi", path.get(0).trim());
	            assertEquals("Town_2 via Road_13 to Town_12 3 mi", path.get(1).trim());
	            assertEquals("Town_12 via Road_14 to Town_13 1 mi", path.get(2).trim());
	            assertEquals("Town_13 via Road_15 to Town_14 4 mi", path.get(3).trim());
	        } else
	            fail("Town names are not valid");
	    }
	 @Test
	    public void testTown_3ToTown_12() {
	        String beginTown = "Town_3", endTown = "Town_12";
	        Town beginIndex = null, endIndex = null;
	        Set<Town> towns = graph.vertexSet();
	        Iterator<Town> iterator = towns.iterator();
	        while (iterator.hasNext()) {
	            Town town = iterator.next();
	            if (town.getName().equals(beginTown))
	                beginIndex = town;
	            if (town.getName().equals(endTown))
	                endIndex = town;
	        }
	        if (beginIndex != null && endIndex != null) {

	            ArrayList<String> path = graph.shortestPath(beginIndex, endIndex);
	            assertNotNull(path);
	            assertTrue(path.size() > 0);
	            assertEquals("Town_3 via Road_2 to Town_1 5 mi", path.get(0).trim());
	            assertEquals("Town_1 via Road_1 to Town_2 3 mi", path.get(1).trim());
	        } else
	            fail("Town names are not valid");
	    }

	
	@After
	public void tearDown() throws Exception {
		graph = null;
	}
	
	
	
}
