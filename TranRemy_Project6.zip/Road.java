import java.util.Objects;

/**
 * Represents a road between two towns in a graph.
 * 
 * This class provides methods to retrieve information about the road,
 * such as its name, starting and destination towns, and weight (distance).
 * It also includes methods for hash code generation, equality comparison, and
 * comparison based on road weights.
 * 
 * @author Remy Tran
 */
public class Road implements Comparable<Road> {
    // Class Variables
    protected Town start = null;
    protected Town end = null;
    protected String roadName = "";
    protected int roadWeight = 0;

    /**
     * Constructor for Road with a specified weight and name.
     * 
     * @param start The starting town of the road.
     * @param end The destination town of the road.
     * @param roadWeight The weight (distance) of the road.
     * @param roadName The name of the road.
     */
    public Road(Town start, Town end, int roadWeight, String roadName) {
        this.start = start;
        this.end = end;
        this.roadWeight = roadWeight;
        this.roadName = roadName;
    }

    /**
     * Constructor for Road with a default weight of 1 and a specified name.
     * 
     * @param start The starting town of the road.
     * @param end The destination town of the road.
     * @param roadName The name of the road.
     */
    public Road(Town start, Town end, String roadName) {
        this.start = start;
        this.end = end;
        this.roadWeight = 1;
        this.roadName = roadName;
    }

    /**
     * Get the name of the road.
     * 
     * @return The name of the road.
     */
    public String getName() {
        return this.roadName;
    }

    /**
     * Get the starting town of the road.
     * 
     * @return The starting town of the road.
     */
    public Town getStart() {
        return this.start;
    }

    /**
     * Get the destination town of the road.
     * 
     * @return The destination town of the road.
     */
    public Town getEnd() {
        return this.end;
    }

    /**
     * Get the weight (distance) of the road.
     * 
     * @return The weight of the road.
     */
    public int getWeight() {
        return this.roadWeight;
    }

    /**
     * Generate a hash code for the road based on its name, starting and destination towns, and weight.
     * 
     * @return The hash code of the road.
     */
    @Override
    public int hashCode() {
        return Objects.hash(roadName, start, end, roadWeight);
    }

    /**
     * Get a string representation of the road.
     * 
     * @return The string representation of the road.
     */
    @Override
    public String toString() {
        return this.roadName;
    }

    /**
     * Check if two roads are equal based on their name, starting and destination towns, and weight.
     * 
     * @param obj The object to compare to.
     * @return True if the roads are equal, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Road road = (Road) obj;
        return roadName.equals(road.roadName) &&
               start.equals(road.start) &&
               end.equals(road.end) &&
               roadWeight == road.roadWeight;
    }

    /**
     * Check if the road contains a specific town.
     * 
     * @param town The town to check for.
     * @return True if the road contains the town, false otherwise.
     */
    public boolean contains(Town town) {
        return this.start.equals(town) || this.end.equals(town);
    }

    /**
     * Compare this road to another road based on their weights.
     * 
     * @param road The road to compare to.
     * @return A negative integer, zero, or a positive integer if this road
     *         is less than, equal to, or greater than the specified road.
     */
    @Override
    public int compareTo(Road road) {
        return this.getWeight() - road.getWeight();
    }
}
