import java.util.*;

/**
 * Represents a graph with towns and roads.
 *  A graph management class that implements GraphInterface for towns and roads
 *  Includes methods for adding and removing edges, vertices and finding shortest
 *  paths in the graph
 * @author Remy Tran
 */
public class Graph implements GraphInterface<Town, Road> {
    protected Set<Town> towns = new HashSet<>();
    protected Set<Road> roads = new HashSet<>();
    protected Set<Town> checked;
    protected Set<Town> unchecked;

    /**
     * Adds a road (edge) to the graph between two towns with the specified weight and name.
     * 
     * @param source The source town.
     * @param destination The destination town.
     * @param weight The weight of the road.
     * @param name The name of the road.
     * @return The added road.
     * @throws IllegalArgumentException If source or destination is not in the graph.
     * @throws NullPointerException If source or destination is null.
     */
    @Override
    public Road addEdge(Town source, Town destination, int weight, String name)
            throws IllegalArgumentException, NullPointerException {
        if (source == null || destination == null) {
            throw new NullPointerException("Vertex provided is null");
        }
        if (!containsVertex(source) || !containsVertex(destination)) {
            throw new IllegalArgumentException("Vertex provided is not in the graph");
        }
        source.neighbors.add(destination);
        destination.neighbors.add(source);
        Road result = new Road(source, destination, weight, name);
        roads.add(result);
        return result;
    }

    /**
     * Removes a road (edge) from the graph between two towns with the specified weight and name.
     * 
     * @param source The source town.
     * @param destination The destination town.
     * @param weight The weight of the road.
     * @param name The name of the road.
     * @return The removed road.
     */
    @Override
    public Road removeEdge(Town source, Town destination, int weight, String name) {
        Road result = null;
        for (Iterator<Road> iterator = roads.iterator(); iterator.hasNext();) {
            Road road = iterator.next();
            if (!road.contains(source) || !road.contains(destination)) {
                continue;
            }
            if (weight > -1 && road.getWeight() != weight) {
                continue;
            }
            if (name != null && !road.getName().equalsIgnoreCase(name)) {
                continue;
            }
            source.neighbors.remove(destination);
            destination.neighbors.remove(source);
            iterator.remove(); // Use iterator's remove method to avoid ConcurrentModificationException
            result = road;
            break;
        }
        return result;
    }

    /**
     * Gets the road (edge) between two towns in the graph.
     * 
     * @param source The source town.
     * @param destination The destination town.
     * @return The road between the towns, or null if no such road exists.
     */
    @Override
    public Road getEdge(Town source, Town destination) {
        Road result = null;
        for (Road road : roads) {
            if ((road.getStart().equals(source) && road.getEnd().equals(destination))
                    || (road.getStart().equals(destination) && road.getEnd().equals(source))) {
                result = road;
                break;
            }
        }
        return result;
    }

    /**
     * Checks if the graph contains a road (edge) between two towns.
     * 
     * @param source The source town.
     * @param destination The destination town.
     * @return True if the graph contains the road, false otherwise.
     */
    @Override
    public boolean containsEdge(Town source, Town destination) {
        return getEdge(source, destination) != null;
    }

    /**
     * Adds a town (vertex) to the graph.
     * 
     * @param vertex The town to be added.
     * @return True if the town is added, false if the town already exists in the graph.
     */
    @Override
    public boolean addVertex(Town vertex) {
        if (towns.contains(vertex)) {
            return false;
        }
        towns.add(vertex);
        return true;
    }

    /**
     * Removes a town (vertex) from the graph.
     * 
     * @param vertex The town to be removed.
     * @return True if the town is removed, false if the town doesn't exist in the graph.
     */
    @Override
    public boolean removeVertex(Town vertex) {
        if (vertex == null || !towns.contains(vertex)) {
            return false;
        }
        for (Road road : edgesOf(vertex)) {
            removeEdge(road.getStart(), road.getEnd(), road.getWeight(), road.getName());
        }
        return towns.remove(vertex);
    }

    /**
     * Checks if the graph contains a town (vertex).
     * 
     * @param vertex The town to check.
     * @return True if the graph contains the town, false otherwise.
     */
    @Override
    public boolean containsVertex(Town vertex) {
        return towns.contains(vertex);
    }

    /**
     * Gets the set of all roads (edges) in the graph.
     * 
     * @return The set of roads in the graph.
     */
    @Override
    public Set<Road> edgeSet() {
        return roads;
    }

    /**
     * Gets the set of all roads (edges) connected to a given town.
     * 
     * @param vertex The town for which to retrieve connected roads.
     * @return The set of roads connected to the town.
     */
    @Override
    public Set<Road> edgesOf(Town vertex) {
        Set<Road> result = new HashSet<>();
        for (Road road : roads) {
            if (road.contains(vertex)) {
                result.add(road);
            }
        }
        return result;
    }

    /**
     * Gets the set of all towns (vertices) in the graph.
     * 
     * @return The set of towns in the graph.
     */
    @Override
    public Set<Town> vertexSet() {
        return new HashSet<>(towns);
    }

    /**
     * Finds the shortest path between two towns in the graph using Dijkstra's algorithm.
     * @param source The source town.
     * @param destination The destination town.
     * @return An ArrayList containing the names of towns on the shortest path.
     */
    @Override
    public ArrayList<String> shortestPath(Town source, Town destination) {
        ArrayList<String> paths = new ArrayList<>();
        checked = new HashSet<>();
        unchecked = new HashSet<>(towns);
        checked.add(source);
        unchecked.remove(source);
        for (Town town : towns) {
            town.reset();
        }
        source.distance = 0;
        dijkstraShortestPath(source);
        buildPaths(paths, source, destination);
        Collections.reverse(paths);
        return paths;
    }


    
    /**
     * Uses Dijkstra's algorithm to calculate the shortest paths from a source town.
     * @param source The source town.
     */
    @Override
    public void dijkstraShortestPath(Town source) {
        boolean found = false;
        while (!found && !unchecked.isEmpty()) {
            found = true;
            Town shortestTown = null;
            int shortestDistance = Integer.MAX_VALUE;
            for (Town visited : checked) {
                Set<Town> neighbors = visited.neighbors;
                Set<Town> unvisitedNeighbors = new HashSet<>();
                for (Town neighbor : neighbors) {
                    if (!unchecked.contains(neighbor)) {
                        continue;
                    }
                    unvisitedNeighbors.add(neighbor);
                }
                for (Town neighbor : unvisitedNeighbors) {
                    int weight = calculateWeights(neighbor, visited, source);
                    if (weight < shortestDistance) {
                        shortestDistance = weight;
                        shortestTown = neighbor;
                        neighbor.previous = visited;
                    }
                }
            }

            if (shortestTown != null) {
                found = false;
                shortestTown.distance = shortestDistance;
                checked.add(shortestTown);
                unchecked.remove(shortestTown);
            }
        }
    }


    protected void buildPaths(ArrayList<String> paths, Town source, Town destination) {
    	
        try {
        	
            StringBuilder path = new StringBuilder();
            Road road = getEdge(destination.previous, destination);
            path.append(destination.previous.getName()).append(" via ").append(road.getName())
                    .append(" to ").append(destination.getName()).append(" ").append(road.getWeight()).append(" mi");
            paths.add(path.toString());
            if (!destination.previous.equals(source)) {
                buildPaths(paths, source, destination.previous);
            }
        } catch (Exception e) {
            paths.clear();
        }
        
    }

    protected int calculateWeights(Town unvisited, Town visited, Town source) {
        return unvisited.equals(source) ? 0 : visited.distance + getEdge(visited, unvisited).getWeight();
    }
}
