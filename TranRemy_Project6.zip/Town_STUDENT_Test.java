/*
 * @author Remy Tran
 */
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class Town_STUDENT_Test {
    private Town town1;
    private Town town1Duplicate;
    private Town town2;

    @Before
    public void setUp() {
        town1 = new Town("Town1");
        town1Duplicate = new Town("Town1");
        town2 = new Town("Town2");
    }

    @Test
    public void testGetName() {
        assertEquals("Town1", town1.getName());
        assertEquals("Town2", town2.getName());
    }

    @Test
    public void testHashcode() {
        assertEquals(town1.hashCode(), town1Duplicate.hashCode());
        assertNotEquals(town1.hashCode(), town2.hashCode());
    }

    
    @Test
    public void testEquals() {
        assertTrue(town1.equals(town1Duplicate));
        assertTrue(town1Duplicate.equals(town1)); // Symmetry
        assertFalse(town1.equals(town2));
    }
    
    @Test
    public void testCompareTo() {
        // Test when names are equal
        Town town1 = new Town("Town1");
        Town town1Duplicate = new Town("Town1");
        assertEquals(0, town1.compareTo(town1Duplicate));

        // Test when the first town comes before the second town
        Town town2 = new Town("Town2");
        assertTrue(town1.compareTo(town2) < 0);

        // Test when the first town comes after the second town
        assertTrue(town2.compareTo(town1) > 0);

        // Test when comparing to itself
        assertEquals(0, town1.compareTo(town1));

        // Test with case-insensitive comparison
        Town townCase1 = new Town("town1");
        assertEquals(0, town1.compareTo(townCase1));
    }
    
    @Test
	public void testToString() {
		Town town1 = new Town("Town1");
		Town town2 = new Town("Town2");
		assertEquals("Town1", town1.toString());
		assertEquals("Town2", town2.toString());
	}
    
    @After
    public void tearDown() {
        // Clean up resources if needed
    }
}
